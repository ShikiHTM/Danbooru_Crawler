#pragma once
#include "UserSetting.h"
#include "menu/Menu.h"

UserSettings parseUserSettings(vector<MenuOption> option);
